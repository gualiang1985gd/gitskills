from werkzeug.security import generate_password_hash,check_password_hash


def check_password(pwd,source_password):
    result = check_password_hash(pwd,source_password)
    print result

password = generate_password_hash("password")
print password
check_password(password,"password")


