#encoding:utf-8
import config
import os
import json
from flask import Flask,render_template,request,session,redirect,g,url_for
from decorators import login_required
from flask_socketio import SocketIO
from werkzeug.security import generate_password_hash,check_password_hash
from check_port_status import check_port
from handle_reset_password import jsonGet,changePassword
# import flask_restful

def read_json():
    with open(r"users.json",'r')as load_f:
        load_dict = json.load(load_f)
        username = load_dict["username"]
        password = load_dict["password"]
        group = load_dict["group"]
        status = load_dict["status"]
    return username,password,group,status

app = Flask(__name__)
socketio = SocketIO(app)
app.config['SECRET_KEY'] = os.urandom(24)

@app.route('/')
# @login_required
def index():
    return render_template('index.html')

@app.route('/login/',methods=['GET','POST'])
def login():
    if request.method == 'GET':
        return render_template('login.html')
    else:
        username = request.form.get('username')
        password = request.form.get('password')
        #判断用户名和密码正确
        read_json()
        # user = User.query.filter(User.username == username).first()
        json_username,json_password,json_group,json_status = read_json()
        if username == json_username:
            if json_status == u'disable':
                return render_template('login.html',m=u'The user has been disabled')
            else:
                json_status == u"enable"
                groupname = json_group
                if json_username and check_password_hash(json_password,password):
                    session['user_user'] = json_username
                    #如果想在31天内都不需要登录
                    session.permanent = True
                    if groupname == u'admin':
                        return redirect(url_for('index'))
                else:
                    return render_template('login.html',m=u'The password is incorrect.Please check it before logging in.')
        else:
            return render_template('login.html',m=u'User does not exist')

@app.route('/resetpassword',methods=['GET','POST'])
@login_required
def reset_password():
    if request.method == 'GET':
        return render_template('reset_password.html')
    if request.method == 'POST':
        adminuser = request.form.get('admin_user')
        site = request.form.get('site')
        port = request.form.get('port')
        newpassword = request.form.get('newpassword')
        username = request.form.get('userslist')
        # print site,port,newpassword,userslist
        message = check_port(host='127.0.0.1',port=port)
        # check_port = batch_reset_password(adminuser=adminuser,site=site,port=port,newpassword=newpassword,userslist=userslist)
        if message == 'The port is down!':
            return render_template('reset_password.html',m=message)
        else:
            changePassword(site,port,username,adminuser,newpassword)
            message = "App user password reset completed!"
            return render_template('reset_password.html',m=message)

@app.before_request
def my_before_request():
    user_user = session.get('user_user')
    json_username = read_json()
    if user_user:
        user = json_username
        if user:
            g.user = user

if __name__ == '__main__':
    from werkzeug.contrib.fixers import ProxyFix
    app.wsgi_app = ProxyFix(app.wsgi_app)
    socketio.run(app,host='0.0.0.0',debug=True,port=5001)