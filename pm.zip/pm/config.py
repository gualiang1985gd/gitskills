#encoding:utf-8

import commands

user = "wasadm"
