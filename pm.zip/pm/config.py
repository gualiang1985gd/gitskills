#encoding:utf-8

login_user = "wasadm"
password = "password"
base_path = "/opt/IBM/wlp/usr/server/"

date_import_staging = "accountBatchImport"
data_import_others = {"address":"address","product":"product","exchange-rate":"exchange-rate","user":"user","clients":"clients","accounts":"accounts","cliententitilements":"cliententitilements","holdinggroups":"holdinggroups","holdings":"holdings","documents":"documents","transaction":"transaction","performance":"performance"}
